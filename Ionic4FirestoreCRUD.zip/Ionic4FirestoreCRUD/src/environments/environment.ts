export const environment = {
  production: false,
  firebase:{
    apiKey: "AIzaSyCclVhEZStCdtpdg68lf5Zrm53ngwIRlMU",
    authDomain: "hito02-carme.firebaseapp.com",
    databaseURL: "https://hito02-carme.firebaseio.com",
    projectId: "hito02-carme",
    storageBucket: "hito02-carme.appspot.com",
    messagingSenderId: "358960345066",
    appId: "1:358960345066:web:622094f64e86b7837e0c93"
  }
};